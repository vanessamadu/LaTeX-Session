# Imperial College London LaTeX templates

This is the official research poster template for Imperial
College London. A letter template is also available and a
Beamer theme for slideshows will be released soon.

## Issues

Please report any bugs in the templates on GitHub (https://github.com/ImperialCollegeLondon/imperial_latex_templates/issues).

## Copyright

© Imperial College London, 2024. These templates, including logo and fonts, are 
for use of Imperial staff and students only for university business. All rights 
reserved to the copyright owners.